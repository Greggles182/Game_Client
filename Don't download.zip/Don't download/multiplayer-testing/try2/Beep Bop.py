import client
client.SendPlayerData("ws://localhost:8765", 0, 0, 1, True)